package projeto.CF;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CfApplicationTests {

	@Test
	void contextLoads() {
	}

}
