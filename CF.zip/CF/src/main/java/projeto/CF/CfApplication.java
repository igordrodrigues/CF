package projeto.CF;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CfApplication {

	public static void main(String[] args) {
		SpringApplication.run(CfApplication.class, args);
	}

}
